package login;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {


	private WebDriver webDriver;
	private WebElement element;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
		webDriver=new ChromeDriver();
	}



	@Given("^Verify the login page heading and Provide user name$")
	public void verify_the_login_page_heading_and_Provide_user_name() throws Throwable {
		webDriver.get("file:///D:/Users/antpaul/Desktop/bdd/hotelBooking/login.html");
		assertEquals("Hotel Booking Application", webDriver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1")).getText());
		webDriver.findElement(By.name("userName")).sendKeys("Capgemini");

	}

	@When("^user password is not presernt$")
	public void user_password_is_not_presernt() throws Throwable {
		//webDriver.findElement(By.name("password")).sendKeys(" ");
		element=webDriver.findElement(By.className("btn"));
		element.click();
	}

	@Then("^throw error message 'Please enter password'$")
	public void throw_error_message_Please_enter_password() throws Throwable {
		String innerMsg=webDriver.findElement(By.xpath("//*[@id=\"pwdErrMsg\"]")).getText();
		assertEquals("Please enter password", innerMsg);
		
	}

	@Given("^Verify the login page heading and Provide user password$")
	public void verify_the_login_page_heading_and_Provide_user_password() throws Throwable {
		webDriver.get("file:///D:/Users/antpaul/Desktop/bdd/hotelBooking/login.html");
		assertEquals("Hotel Booking Application", webDriver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1")).getText());
		webDriver.findElement(By.name("password")).sendKeys("capg1234");
	}

	@When("^user name is not presernt$")
	public void user_name_is_not_presernt() throws Throwable {
		element=webDriver.findElement(By.className("btn"));
		element.click();
	}

	@Then("^throw error message 'Please enter user name'$")
	public void throw_error_message_Please_enter_user_name() throws Throwable {
		String innerMsg=webDriver.findElement(By.xpath("//*[@id=\"userErrMsg\"]")).getText();
		assertEquals("Please enter user name", innerMsg);
	}

	@Given("^Verify the login page heading and Provide user name and user password$")
	public void verify_the_login_page_heading_and_Provide_user_name_and_user_password() throws Throwable {
		webDriver.get("file:///D:/Users/antpaul/Desktop/bdd/hotelBooking/login.html");
		webDriver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1")).getText();
		Thread.sleep(1000);
		webDriver.findElement(By.name("userName")).sendKeys("Capgemini");
		webDriver.findElement(By.name("userPwd")).sendKeys("capg1234");
	}

	@When("^user details are valid$")
	public void user_details_are_valid() throws Throwable {
		element=webDriver.findElement(By.className("btn"));
		element.click();
	}

	@Then("^open page hotelbooking$")
	public void open_page_hotelbooking() throws Throwable {
		webDriver.navigate().to("file:///D:/Users/antpaul/Desktop/bdd/hotelBooking/hotelbooking.html");
	}

	/*@After
	public void teardown() {
		webDriver.close();
	}*/




}
