package booking;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	private WebDriver webDriver;
	private WebElement element;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\selenium\\chromedriver.exe");
		webDriver=new ChromeDriver();
	}



	@Given("^Verify the Page title is 'Hotel Booking'$")
	public void verify_the_Page_title_is_Hotel_Booking() throws Throwable {
		webDriver.get("file:///D:/Users/antpaul/Desktop/bdd/hotelBooking/hotelbooking.html");
		String text=webDriver.findElement(By.xpath("/html/body/div/h2")).getText();
		assertEquals("Hotel Booking Form", text);
	}

	@Given("^enter all the details$")
	public void enter_all_the_details() throws Throwable {
		webDriver.findElement(By.name("txtFN")).sendKeys("antara");
		webDriver.findElement(By.name("txtLN")).sendKeys("paul");
		webDriver.findElement(By.name("Email")).sendKeys("ant@capg.com");
		webDriver.findElement(By.name("Phone")).sendKeys("8675940560");
		webDriver.findElement(By.xpath("/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("Kolkata");

		WebElement mySelectElement = webDriver.findElement(By.name("city"));
		Select dropdown= new Select(mySelectElement);
		dropdown.selectByVisibleText("Pune");
		WebElement mySelectstate = webDriver.findElement(By.name("state"));
		Select dropdownState= new Select(mySelectstate);
		dropdownState.selectByVisibleText("Maharashtra");
		WebElement persons = webDriver.findElement(By.name("persons"));
		Select dropdownpersons= new Select(persons);
		dropdownpersons.selectByVisibleText("1");

		webDriver.findElement(By.xpath("//*[@id=\"txtCardholderName\"]")).sendKeys("Antara");
		webDriver.findElement(By.name("debit")).sendKeys("56785008956723");
		webDriver.findElement(By.name("cvv")).sendKeys("784");
		webDriver.findElement(By.name("month")).sendKeys("10");
		webDriver.findElement(By.name("year")).sendKeys("2018");


	}

	@When("^Click confirm booking button$")
	public void click_confirm_booking_button() throws Throwable {
		WebElement confirm=webDriver.findElement(By.xpath("//*[@id=\"btnPayment\"]"));
		confirm.click();

	}

	@Then("^show 'Booking Complete' in success page$")
	public void show_Booking_Complete_in_success_page() throws Throwable {
		webDriver.navigate().to("file:///D:/Users/antpaul/Desktop/bdd/hotelBooking/success.html");
	}

	@Given("^First Name is missing$")
	public void first_Name_is_missing() throws Throwable {
		webDriver.get("file:///D:/Users/antpaul/Desktop/bdd/hotelBooking/hotelbooking.html");
		String text=webDriver.findElement(By.xpath("/html/body/div/h2")).getText();
		assertEquals("Hotel Booking Form", text);
		webDriver.findElement(By.name("txtFN")).sendKeys("");
	}

	@When("^Click confirm Booking$")
	public void click_confirm_Booking() throws Throwable {
		WebElement confirm=webDriver.findElement(By.xpath("//*[@id=\"btnPayment\"]"));
		confirm.click();
	}

	@Then("^show 'Please fill first name'$")
	public void show_Please_fill_first_name() throws Throwable {
		String msg = webDriver.switchTo().alert().getText();
		assertEquals("Please fill the First Name",msg);
	}
	
	@Given("^State is missing$")
	public void state_is_missing() throws Throwable {
		webDriver.get("file:///D:/Users/antpaul/Desktop/bdd/hotelBooking/hotelbooking.html");
		String text=webDriver.findElement(By.xpath("/html/body/div/h2")).getText();
		assertEquals("Hotel Booking Form", text);
		
		webDriver.findElement(By.name("txtFN")).sendKeys("antara");
		webDriver.findElement(By.name("txtLN")).sendKeys("paul");
		webDriver.findElement(By.name("Email")).sendKeys("ant@capg.com");
		webDriver.findElement(By.name("Phone")).sendKeys("8675940560");
		webDriver.findElement(By.xpath("/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("Kolkata");

		WebElement mySelectElement = webDriver.findElement(By.name("city"));
		Select dropdown= new Select(mySelectElement);
		dropdown.selectByVisibleText("Pune");
		WebElement mySelectstate = webDriver.findElement(By.name("state"));
		Select dropdownState= new Select(mySelectstate);
		//dropdownState.selectByVisibleText("Maharashtra");
		WebElement persons = webDriver.findElement(By.name("persons"));
		Select dropdownpersons= new Select(persons);
		dropdownpersons.selectByVisibleText("1");

		webDriver.findElement(By.xpath("//*[@id=\"txtCardholderName\"]")).sendKeys("Antara");
		webDriver.findElement(By.name("debit")).sendKeys("56785008956723");
		webDriver.findElement(By.name("cvv")).sendKeys("784");
		webDriver.findElement(By.name("month")).sendKeys("10");
		webDriver.findElement(By.name("year")).sendKeys("2018");

		
	}
	
	@When("^Click the confirm Booking$")
	public void click_the_confirm_Booking() throws Throwable {
		WebElement confirm=webDriver.findElement(By.xpath("//*[@id=\"btnPayment\"]"));
		confirm.click();
	}



	@Then("^show 'Please select state'$")
	public void show_Please_select_state() throws Throwable {
		String msg1 = webDriver.switchTo().alert().getText();
		assertEquals("Please select state",msg1);
	    
	}



}
