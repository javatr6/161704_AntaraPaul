package com.cap.org;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer {
	@Id
	private int customerId;
	private String custName;
	private float registFees;
	private Date registDate;
	
	public Customer() {
		super();
	}
	
	public Customer(int customerId, String custName, float registFees, Date registDate) {
		super();
		this.customerId = customerId;
		this.custName = custName;
		this.registFees = registFees;
		this.registDate = registDate;
	}

	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public float getRegistFees() {
		return registFees;
	}
	public void setRegistFees(float registFees) {
		this.registFees = registFees;
	}
	public Date getRegistDate() {
		return registDate;
	}
	public void setRegistDate(Date registDate) {
		this.registDate = registDate;
	}
	
	

}
