package com.cap.org;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class CustomerTester {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		
		transaction.begin();
		/*SimpleDateFormat dateFormat=new SimpleDateFormat("dd/MM/yyyy");
		Date date2=dateFormat.p*/
		Customer customer=new Customer(102,"antara",400.00F,new Date());
		entityManager.persist(customer);
		transaction.commit();
		 entityManager.close();

	}

}
