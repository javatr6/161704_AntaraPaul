package com.org.OneToOne;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class CustomerMappingTester {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		
		transaction.begin();
		
		Customer antara=new Customer("antara",1000.00F);
		Address adress1=new Address("ASANSOL",antara);
		
		
		entityManager.persist(antara);
		entityManager.persist(adress1);
		transaction.commit();
		 entityManager.close();

	}

}
