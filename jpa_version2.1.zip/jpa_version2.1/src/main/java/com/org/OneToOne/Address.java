package com.org.OneToOne;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Address {
	@Id
	@GeneratedValue
	private int addressId;
	private String address;
	
	@OneToOne
	@JoinColumn(name="custFk")
	private Customer custId;
	
	public Address() {
		
	}
	

	public Address(int addressId, String address, Customer custId) {
		super();
		this.addressId = addressId;
		this.address = address;
		this.custId = custId;
	}


	public Address(String address, Customer custId) {
		super();
		
		this.address = address;
		this.custId = custId;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Customer getCustId() {
		return custId;
	}

	public void setCustId(Customer custId) {
		this.custId = custId;
	}

	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", address=" + address + ", custId=" + custId + "]";
	}
	
	
	
	

}
