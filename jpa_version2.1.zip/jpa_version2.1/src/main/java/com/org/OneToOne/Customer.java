package com.org.OneToOne;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Customer {
	@Id
	@GeneratedValue
	private int custId;
	private String firstName;
	private float registFee;
	
	public Customer() {
		
	}
	
	
	
	public Customer(int custId, String firstName, float registFee) {
		super();
		this.custId = custId;
		this.firstName = firstName;
		this.registFee = registFee;
	}



	public Customer(String firstName, float registFee) {
		super();
		
		this.firstName = firstName;
		this.registFee = registFee;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public float getRegistFee() {
		return registFee;
	}

	public void setRegistFee(float registFee) {
		this.registFee = registFee;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", firstName=" + firstName + ", registFee=" + registFee + "]";
	}
	
	
	

}
