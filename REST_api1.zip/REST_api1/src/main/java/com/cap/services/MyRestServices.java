package com.cap.services;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

@Path("/api")
public class MyRestServices {
	
	@GET
	@Path("/hello")
	public String sayHello() {
		return "helloo";
		
		
	}

}
