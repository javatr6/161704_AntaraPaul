package com.capgemini.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class BusPassTableJPA {

	public static void main(String[] args) {
		EntityManagerFactory emf = 
        		Persistence.createEntityManagerFactory("jpademo");
        EntityManager enitity_manager = emf.createEntityManager();
        EntityTransaction transaction= enitity_manager.getTransaction();
        
        transaction.begin();
     Login login=new Login("antara","antara123");
     Login login1=new Login("aru","aru123");
     Login login2=new Login("ashu","ashu123");
     Login login3=new Login("ankita","ankita123");

     
      
     Busroute busroute=new Busroute();
     busroute.setRoutePath("Chengalpattu-Paranur-MIPL");
     busroute.setRouteName("MIPL");
     busroute.setOccupied(15);
     busroute.setTotalSeats(30);
     busroute.setDiverName("Abc");
     busroute.setBusNo("TN-5675");
     busroute.setTotalKm(50);
     
       
     enitity_manager.persist(login);
     enitity_manager.persist(login1);
     enitity_manager.persist(login2);
     enitity_manager.persist(login3);
        
     enitity_manager.persist(busroute);
        transaction.commit();
        enitity_manager.close();

	}

}
